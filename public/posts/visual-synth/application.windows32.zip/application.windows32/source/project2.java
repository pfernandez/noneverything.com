import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import controlP5.*; 
import rwmidi.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class project2 extends PApplet {

/*
VISUAL SYNTH

For this project, I was interested in exploring the resonances
that emerge via the constructive self-interference of oscilating
time-based patterns. In the same way that an audio synthesizer
can produce an infinite variety of tones by combining simple
waveforms, this application can be used to generate an infinite
variety of patterns using only a single rotating ellipse. In the
future I plan on expanding it with other visualizations, as well
as adding the capacity to generate unique sounds along with the
images, using the same parameters.

Because this is ultimately intended for use as a performance
instrument, I've written it to incude the option to be controlled
with a Midi controller as an alternative to the on-screen controllers.
This is still under development. Although it currently works with
my M-Audio Oxygen49 keyboard, using a different controller would
involve reassigning the Midi CC values in the "controls" file. Also,
the "note" intervals have not yet been mapped to the Midi keys.

For the required data set, I was looking for something that had
the potential to help locate resonant patterns in the elliptical
oscillations. I chose to use the energetic states of the hydrogen
atom (see http://astro.unl.edu/naap/hydrogen/levels.html.) I set the
energy of a "free" electron, -13.6 eV, to 1, leaving only the series
1/1, 1/4, 1/9, ..., 1/n^2. These are mapped to buttons ("keys") laid
out along the bottom of the screen. When the speed of rotation is
turned all the way up in a given direction (i.e. with the ROTATE X
slider,) the ellipse will oscillate with a period of 2pi*1/n^2 per
frame, with n determined by the button last clicked.


Required Libraries:
  ControlP5:  http://www.sojamo.de/libraries/controlP5/
  RWMidi:     http://ruinwesen.com/blog?id=95


Paul Fernandez 2012
Digital Arts 252
University of Oregon 
*/



public void setup() {
  //size( 1200, 800, OPENGL );
  size(screen.width, screen.height, OPENGL);
  hint( ENABLE_OPENGL_4X_SMOOTH );
  hint( DISABLE_DEPTH_TEST );
  setupControls( "screen" ); // either "screen" or "midi"
}

public void draw() {
  noFill();
  
  // draw something
  funWithEllipse();
  
  // fade out the drawing
  fadeOut();
  
  // adjust the speed
  changeSpeed();
}
/*
Sets up on-screen or midi conrols depending
on selection in setup() function.
*/



int nControls      = 19;  // the number of variable controllers, i.e. sliders or knobs
int nNotes         = 17;  // the number of buttons or midi keys
int fineTuneIndex  = 17;  // slider for tweaking note intervals or midi pitch bender

// dependent global variables
float[] controls       = null;
String[] controlLabels = null;
float[] controlMins    = null;
float[] controlMaxs    = null;
float[] notes          = null;
String[] noteLabels    = null;
int[][] uniqueCCs      = null;
int noteIndex          = 0;
ControlP5 cp5;

// setup midi controls if available, otherwise use controlP5
public void setupControls( String controlType ) {
  
  
  /* General settings for both on-screen and midi controls
  -----------------------------------------------------------------*/

  String[] controlLabelVals = {
    "red", "green", "blue", "fill", "background", "fade",
    "translate x", "translate y", "translate z",
    "rotate x", "rotate y", "rotate z",
    "x diameter", "y diameter",
    "translate-2 x", "translate-2 y", "translate-2 z",
    "fine-tune interval", "framerate"
  };
  controlLabels = controlLabelVals;
  
  float[] controlVals = {
    0, 0, 0, 0.1f * 255, 0.98f * 255, 0.5f * 255,
    0.5f * width, 0.5f * height, 0,
    0, 0, 0,
    0.5f * width, 0.5f * width,
    0, 0, 0,
    0, 30
  };
  controls = controlVals;
  
  float[] controlMinVals = {
    0, 0, 0, 0, 0, 255,
    0, height, - 4.0f * width,
    0, 0, 0,
    0, 0,
    -width, -height, -width,
    -1, 5
  };
  controlMins = controlMinVals;
                           
  float[] controlMaxVals = { 
    255, 255, 255, 255, 255, 0,
    width, 0, 0.5f * width,
    TWO_PI, TWO_PI, TWO_PI,
    width, width,
    width, height, width,
    1, 80
  };
  controlMaxs = controlMaxVals;

  String[] noteLabelVals = {
    "1",     "1/4",   "1/9",   "1/16",
    "1/25",  "1/36",  "1/49",  "1/64",
    "1/81",  "1/100", "1/121", "1/144",
    "1/169", "1/196", "1/225", "1/256"
  };
  noteLabels = noteLabelVals;
  
  float[] noteVals = {
    1.f,     1/4.f,   1/9.f,   1/16.f,
    1/25.f,  1/36.f,  1/49.f,  1/64.f,
    1/81.f,  1/100.f, 1/121.f, 1/144.f,
    1/169.f, 1/196.f, 1/225.f, 1/256.f,
    1/289.f
  };
  notes = noteVals;
  
  /* End general settings
  -------------------------------------------------------------*/
  

  // put controllers on the screen if selected
  if( "screen" == controlType ) {
        
    cp5 = new ControlP5( this );
    
    // set up controls
    for( int i = 0; i < nControls; i++ ) {
      cp5.addSlider( "controls" + i )
      .setPosition( 10, i * 24 + 14 )
      .setSize( 100, 10 )
      .setRange( controlMins[i], controlMaxs[i] )
      .setValue( controls[i] )
      .setCaptionLabel( controlLabels[i] )
      .setColorCaptionLabel( 93342 )
      .setId( i )
     ;
    }
    // set up buttons
    for( int i = 0; i < nNotes - 1; i++ ) {
      cp5.addButton( "notes" + i )
       .setPosition( ( width - nNotes * 40 ) + i * 40, height - 70 )
       .setSize( 30, 60 )
       .changeValue( notes[i] )
       .setCaptionLabel( noteLabels[i] )
       .setId( i )
       ;
    }
    // add a label to the row of buttons
    cp5.addTextlabel( "label" )
       .setText( "INTERVAL" )
       .setPosition( width - nNotes * 40 - 3, height - 80 )
       .setColorValue( 93342 )
       ;
  }   
  // set up midi if selected
  else if( "midi" == controlType ) {
    
    MidiInput input   = RWMidi.getInputDevices()[0].createInput( this );
    MidiOutput output = RWMidi.getOutputDevices()[0].createOutput();
    println( "Midi device list:" );
    println( RWMidi.getInputDeviceNames() );
    println( "Input: "+input.getName() );
    println( "Output: "+output.getName() );
    
    /*
    Midi CC numbers might be any integer. However, we need values of
    1, 2, ..., N. Map the midi values here by putting each CC number
    into the index of an array.
    */
    int numCCs = nControls;
    int[] ccValues = new int[numCCs];
    for( int i = 0; i < numCCs; i++ ) {
      // just filling it with monotonic integers for now
      ccValues[i] = i + 1;
    }
    // overwriting with unique values where necessary
    ccValues[ccValues.length - 2] = 33;  // this is my pitch bend wheel
    ccValues[ccValues.length - 1] = 34;  // this is my modulation wheel
    
    // pick out only non-montonic values to save time
    // while determining which CC was triggered
    int[][] uniqueCCVals = new int[nControls][2];
    int nUniqueCCs = 0;
    for( int i = 0; i < numCCs; i++ ) {
      if( i + 1 != ccValues[i] ) {
        uniqueCCVals[nUniqueCCs][0] = i;  // the index of our controller
        uniqueCCVals[nUniqueCCs][1] = ccValues[i];  // the CC of our controller
        nUniqueCCs++;
      }
    }
    uniqueCCs = new int[nUniqueCCs][2];
    arrayCopy( uniqueCCVals, uniqueCCs, nUniqueCCs );  // put it the global array
    
    // print controller info
    println( "\nAvailable controls:" );
    for( int i = 0; i < nControls; i++ ) {
      println( (i+1) + ": " + controlLabels[i] + ", [" +
              controlMins[i] + ", " + controlMaxs[i] + "]");
    }
  }
  else println( "Argument of \"midi\" or \"screen\" required." );
}

/*
Thanks to andreas.schlegel on the Processing forums for providing the
base code for the following function.
http://forum.processing.org/topic/change-array-variable-with-controlp5
*/
// ControlP5 workaround allowing access to controls stored in an array
public void controlEvent( ControlEvent theEvent ) {
  if( theEvent.isController() ) {
    if( theEvent.controller().name().startsWith( "controls" ) ) {
      int id = theEvent.controller().id();
      if ( id >= 0 && id < nControls )
        controls[id] = theEvent.value();
    }
    else if ( theEvent.controller().name().startsWith( "notes" ) ) {
      int id = theEvent.controller().id();
      if ( id >= 0 && id < nNotes ) {
        cp5.getController( "controls" + fineTuneIndex ).setValue( 0 );    
        noteIndex = id;
      }
    }
  }
}

// midi signals from keys
public void noteOnReceived( Note note ) {
  println( "Note on: " + note.getPitch() + ", velocity: " + note.getVelocity() );
}
public void noteOffReceived( Note note ) {
  println( "Note off: " + note.getPitch() );
}

// midi signals from other controllers
public void controllerChangeReceived( rwmidi.Controller controller ) {
  int ccIndex = controller.getCC() - 1;
  int signal  = controller.getValue();
  for( int i = 0; i < uniqueCCs.length; i++ ) {
      if( ccIndex == uniqueCCs[i][1] - 1 ) {
        ccIndex = uniqueCCs[i][0];
      }
    }
  if( ccIndex < nControls ) {
    controls[ccIndex] = map( signal, 0, 127, controlMins[ccIndex],
                             controlMaxs[ccIndex] );
    //println( "Controller: " + (ccIndex+1) + ", value: " + controls[ccIndex] );
  }
}
/*
Miscellaneous funcions.
*/

// translate, transform, and color ellipse in real-time
public void funWithEllipse() {
  float angle = getRotationAngle();
  pushMatrix();
  fill      ( controls[0], controls[1], controls[2], controls[3] );
  stroke    ( controls[0], controls[1], controls[2] );
  translate ( controls[6],  controls[7],  controls[8] );
  rotateX   ( controls[9] * angle );
  rotateY   ( controls[10] * angle );
  rotateZ   ( controls[11] * angle );
  translate ( controls[14],  controls[15],  controls[16] );
  ellipse   ( 0, 0, controls[12], controls[13] );
  popMatrix();
}

// set frequency based on note pressed
public float getRotationAngle() {
  float intervalSize = notes[noteIndex + 1] - notes[noteIndex];
  float frequency = notes[noteIndex] + map( controls[fineTuneIndex],
                                            controlMins[fineTuneIndex],
                                            controlMaxs[fineTuneIndex], 
                                            -intervalSize,
                                            intervalSize );
  return frequency * frameCount;
}

// adjust tracers
public void fadeOut() {
  fill( controls[4], 1.5f * controls[5] - 127.5f );
  rect( 0, 0, width, height );
}

// adjust the timestep
public void changeSpeed() {
 frameRate(controls[18]);
}

/*
Thanks to user PhiLho on the Processing forums for 
providing the outline of the following function.
http://processing.org/discourse/beta/num_1242790263.html
*/
// press any key to pause/play
boolean pause = false;
public void keyPressed() {
  pause = ! pause;
  if ( pause )
    noLoop();
  else
    loop();
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--hide-stop", "project2" });
  }
}
